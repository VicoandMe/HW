#ifndef __OJ_H__
#define __OJ_H__



void GetResult(char* pInput[], int Num, char* pResult);

#endif
