#ifndef __OJ_H__
#define __OJ_H__





void GetResult(int InMinSeq, int InMaxSeq, int InNumbLen, char *InChaStr, char *pBufOutData);


#endif
