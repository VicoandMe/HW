#ifndef __OJ_H__
#define __OJ_H__

bool FindTwoNumbersWithSum(int aData[], unsigned int uiLength, int sum, int *pNum1, int *pNum2);

#endif
